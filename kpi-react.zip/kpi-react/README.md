# KPI Hub (React)
npm install && npm run dev   # local
npm run build                # outputs dist/ — deploy dist/ to GitHub Pages
Login: admin / admin123. Uses the same localStorage keys as the old site.
