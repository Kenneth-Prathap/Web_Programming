import { useLocal } from '../lib/kpi.js';
import { Card, Stat, ScoreBar, ScoreBadge, Empty } from '../components/ui.jsx';
export default function Dashboard() {
  const [emps] = useLocal('kpi_employees'); const sorted = [...emps].sort((a, b) => b.kpi - a.kpi);
  const avg = emps.length ? Math.round(emps.reduce((s, e) => s + e.kpi, 0) / emps.length) : '—';
  const count = f => emps.filter(e => f(e.kpi)).length;
  return (<>
    <h1 className="title">Dashboard</h1><p className="muted sub">Team performance at a glance</p>
    <div className="stats">
      <Stat label="Employees" value={emps.length} color="var(--blue)" />
      <Stat label="Excellent" value={count(s => s >= 120)} color="var(--green)" />
      <Stat label="Good" value={count(s => s >= 90 && s < 120)} color="var(--amber)" />
      <Stat label="Poor" value={count(s => s < 90)} color="var(--red)" />
      <Stat label="Avg score" value={avg} color="var(--violet)" />
    </div>
    <Card title="🏆 Leaderboard" pad={false}>
      {!sorted.length ? <Empty>No employees yet. Add some in the Employees tab.</Empty> :
        <table><thead><tr><th>#</th><th>Name</th><th>Department</th><th>Score</th><th>Status</th></tr></thead>
          <tbody>{sorted.map((e, i) => <tr key={e.id}><td>{i + 1}</td><td><b>{e.name}</b><div className="muted s">{e.designation}</div></td>
            <td>{e.department}</td><td><ScoreBar score={e.kpi} /></td><td><ScoreBadge score={e.kpi} /></td></tr>)}</tbody></table>}
    </Card></>);
}
