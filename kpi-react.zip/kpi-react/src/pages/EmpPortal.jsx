import { useNavigate } from 'react-router-dom';
import { useLocal, fmtMonth } from '../lib/kpi.js';
import { getSession, logout } from '../lib/auth.js';
import { Card, Stat, ScoreBar, ScoreBadge, Empty } from '../components/ui.jsx';
export default function EmpPortal() {
  const nav = useNavigate(); const s = getSession();
  const [emps] = useLocal('kpi_employees'); const [entries] = useLocal('kpi_entries'); const [att] = useLocal('kpi_attendance');
  const me = emps.find(e => e.id == s.empId); const mine = entries.filter(e => e.empId == s.empId);
  const myAtt = att.filter(a => a.empId == s.empId);
  return (
    <div className="main" style={{ margin: '0 auto' }}>
      <div className="between"><div><h1 className="title">Hi, {s.name.split(' ')[0]} 👋</h1><p className="muted sub">{me?.designation} · {me?.department}</p></div>
        <button className="btn" onClick={() => { logout(); nav('/login'); }}>🚪 Logout</button></div>
      <div className="stats"><Stat label="Current KPI" value={me?.kpi ?? '—'} color="var(--blue)" /><Stat label="Entries" value={mine.length} color="var(--violet)" />
        <Stat label="Days present" value={myAtt.filter(a => a.status === 'Present' || a.status === 'WFH').length} color="var(--green)" /></div>
      <Card title="📋 My KPI history" pad={false}>
        {!mine.length ? <Empty>No KPI entries yet.</Empty> :
          <table><thead><tr><th>Month</th><th>Tasks</th><th>Bugs</th><th>Hours</th><th>Score</th><th>Status</th></tr></thead>
            <tbody>{mine.map(e => <tr key={e.id}><td>{fmtMonth(e.month)}</td><td>{e.tasks}</td><td>{e.bugs}</td><td>{e.hours}</td><td><ScoreBar score={e.score} /></td><td><ScoreBadge score={e.score} /></td></tr>)}</tbody></table>}
      </Card></div>);
}
