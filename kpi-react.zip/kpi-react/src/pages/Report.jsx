import { useState } from 'react';
import { useLocal, perf, fmtMonth } from '../lib/kpi.js';
import { Card, Stat, ScoreBadge, Empty } from '../components/ui.jsx';
export default function Report() {
  const [entries] = useLocal('kpi_entries'); const [m, setM] = useState(new Date().toISOString().slice(0, 7));
  const rows = entries.filter(e => e.month === m).sort((a, b) => b.score - a.score);
  const avg = rows.length ? Math.round(rows.reduce((s, e) => s + e.score, 0) / rows.length) : '—';
  const max = Math.max(150, ...rows.map(r => r.score));
  return (<>
    <div className="between"><div><h1 className="title">Monthly report</h1><p className="muted sub">{fmtMonth(m)}</p></div>
      <div className="row"><input type="month" value={m} onChange={e => setM(e.target.value)} /><button className="btn" onClick={() => window.print()}>🖨 Print</button></div></div>
    <div className="stats"><Stat label="Entries" value={rows.length} color="var(--blue)" /><Stat label="Avg score" value={avg} color="var(--violet)" />
      <Stat label="Top" value={rows[0]?.empName ?? '—'} color="var(--green)" /></div>
    <Card title="📈 Scores">
      {!rows.length ? <Empty>No KPI entries for this month.</Empty> :
        <div className="chart">{rows.map(r => <div key={r.id} className="col" title={`${r.empName}: ${r.score}`}>
          <b>{r.score}</b><i style={{ height: r.score / max * 100 + '%', background: perf(r.score).color }} /><span>{r.empName.split(' ')[0]}</span></div>)}</div>}
    </Card>
    {!!rows.length && <Card title="Details" pad={false}><table><thead><tr><th>#</th><th>Employee</th><th>Tasks</th><th>Bugs</th><th>Hours</th><th>Score</th><th>Status</th></tr></thead>
      <tbody>{rows.map((r, i) => <tr key={r.id}><td>{i + 1}</td><td><b>{r.empName}</b></td><td>{r.tasks}</td><td>{r.bugs}</td><td>{r.hours}</td><td><b>{r.score}</b></td><td><ScoreBadge score={r.score} /></td></tr>)}</tbody></table></Card>}
  </>);
}
