import { useState } from 'react';
import { useLocal } from '../lib/kpi.js';
import { Card, ScoreBadge, Empty } from '../components/ui.jsx';
const blank = { name: '', department: '', designation: '', kpi: 0, joinDate: '' };
export default function Employees() {
  const [emps, setEmps] = useLocal('kpi_employees'); const [f, setF] = useState(blank);
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const add = e => { e.preventDefault(); setEmps([...emps, { ...f, id: Date.now(), kpi: +f.kpi }]); setF(blank); };
  const del = id => confirm('Remove this employee?') && setEmps(emps.filter(e => e.id !== id));
  return (<>
    <h1 className="title">Employees</h1><p className="muted sub">Manage your team</p>
    <div className="grid2">
      <Card title="👤 Add employee"><form className="form" onSubmit={add}>
        <label>Full name<input required value={f.name} onChange={set('name')} placeholder="Raj Kumar" /></label>
        <label>Department<input required value={f.department} onChange={set('department')} placeholder="IT, Cloud…" /></label>
        <label>Designation<input required value={f.designation} onChange={set('designation')} placeholder="Developer" /></label>
        <label>Initial KPI (0–150)<input required type="number" min="0" max="150" value={f.kpi} onChange={set('kpi')} /></label>
        <label>Join date<input required type="date" value={f.joinDate} onChange={set('joinDate')} /></label>
        <button className="btn">Add employee</button></form></Card>
      <Card title={`Team (${emps.length})`} pad={false}>
        {!emps.length ? <Empty>No employees yet.</Empty> :
          <table><thead><tr><th>Name</th><th>Dept</th><th>KPI</th><th /></tr></thead>
            <tbody>{emps.map(e => <tr key={e.id}><td><b>{e.name}</b></td><td>{e.department}</td><td><ScoreBadge score={e.kpi} /> {e.kpi}</td>
              <td><button className="x" onClick={() => del(e.id)}>✕</button></td></tr>)}</tbody></table>}
      </Card></div></>);
}
