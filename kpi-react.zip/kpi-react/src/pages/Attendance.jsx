import { useState } from 'react';
import { useLocal } from '../lib/kpi.js';
import { Card, Stat, Empty } from '../components/ui.jsx';
const ST = { Present: 'var(--green)', Absent: 'var(--red)', Leave: 'var(--amber)', WFH: 'var(--blue)' };
export default function Attendance() {
  const [emps] = useLocal('kpi_employees'); const [recs, setRecs] = useLocal('kpi_attendance');
  const [f, setF] = useState({ empId: '', date: new Date().toISOString().slice(0, 10), status: 'Present', note: '' });
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const log = e => {
    e.preventDefault(); const emp = emps.find(x => x.id == f.empId); if (!emp) return;
    const entry = { id: Date.now(), empId: emp.id, empName: emp.name, ...f };
    setRecs([entry, ...recs.filter(r => !(r.empId == emp.id && r.date === f.date))]); setF({ ...f, note: '' });
  };
  return (<>
    <h1 className="title">Attendance</h1><p className="muted sub">Log and review daily attendance</p>
    <div className="stats">{Object.keys(ST).map(s => <Stat key={s} label={s} value={recs.filter(r => r.status === s).length} color={ST[s]} />)}</div>
    <div className="grid2">
      <Card title="📅 Log attendance"><form className="form" onSubmit={log}>
        <label>Employee<select required value={f.empId} onChange={set('empId')}><option value="">Choose…</option>{emps.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select></label>
        <label>Date<input type="date" required value={f.date} onChange={set('date')} /></label>
        <label>Status<select value={f.status} onChange={set('status')}>{Object.keys(ST).map(s => <option key={s}>{s}</option>)}</select></label>
        <label>Note<input value={f.note} onChange={set('note')} placeholder="Optional" /></label>
        <button className="btn">Log</button></form></Card>
      <Card title="Records" pad={false}>
        {!recs.length ? <Empty>No records yet.</Empty> :
          <table><thead><tr><th>Employee</th><th>Date</th><th>Status</th><th>Note</th><th /></tr></thead>
            <tbody>{recs.map(r => <tr key={r.id}><td><b>{r.empName}</b></td><td>{r.date}</td>
              <td><span className="badge" style={{ '--c': ST[r.status] }}>{r.status}</span></td><td className="muted">{r.note || '—'}</td>
              <td><button className="x" onClick={() => setRecs(recs.filter(x => x.id !== r.id))}>✕</button></td></tr>)}</tbody></table>}
      </Card></div></>);
}
