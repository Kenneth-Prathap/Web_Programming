import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login, resetPassword } from '../lib/auth.js';
import { useLocal } from '../lib/kpi.js';

function ForgotModal({ onClose }) {
  const [emps] = useLocal('kpi_employees');
  const [role, setRole] = useState('admin');
  const [empId, setEmpId] = useState(''); const [p1, setP1] = useState(''); const [p2, setP2] = useState('');
  const [msg, setMsg] = useState(null);
  const submit = e => {
    e.preventDefault();
    const r = resetPassword(role, empId, p1, p2);
    setMsg(r.error ? { t: 'err', m: r.error } : { t: 'ok', m: 'Password updated! You can sign in now.' });
    if (r.ok) { setP1(''); setP2(''); }
  };
  return (
    <div className="lg-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <form className="lg-modal" onSubmit={submit}>
        <h3>🔑 Reset password</h3>
        <div className="lg-tabs">{['admin', 'employee'].map(r =>
          <button type="button" key={r} className={role === r ? 'on' : ''} onClick={() => { setRole(r); setMsg(null); }}>{r === 'admin' ? '🛡 Admin' : '👤 Employee'}</button>)}</div>
        {role === 'employee' && <><label>Employee</label>
          <select value={empId} onChange={e => setEmpId(e.target.value)}><option value="">— Choose employee —</option>
            {emps.map(e => <option key={e.id} value={e.id}>{e.name} — {e.department}</option>)}</select></>}
        <label>New password</label><input type="password" value={p1} onChange={e => setP1(e.target.value)} placeholder="Min 6 characters" />
        <label>Confirm password</label><input type="password" value={p2} onChange={e => setP2(e.target.value)} placeholder="Re-enter password" />
        {msg && <div className={'lg-msg ' + msg.t}>{msg.m}</div>}
        <button className="lg-btn" type="submit">Update password</button>
        <button type="button" className="lg-link center" onClick={onClose}>Close</button>
      </form>
    </div>);
}

export default function Login() {
  const nav = useNavigate();
  const [role, setRole] = useState('admin');
  const [u, setU] = useState(''); const [p, setP] = useState('');
  const [err, setErr] = useState(''); const [forgot, setForgot] = useState(false);
  const isAdmin = role === 'admin';
  const switchRole = r => { setRole(r); setU(''); setP(''); setErr(''); };
  const submit = e => {
    e.preventDefault();
    const r = login(role, u, p);
    if (r.error) { setErr(r.error); setP(''); return; }
    nav(isAdmin ? '/' : '/portal');
  };
  return (
    <div className="lg">
      <div className="lg-card">
        <div className="lg-head">
          <span className="lg-logo">{isAdmin ? '📊' : '👤'}</span>
          <h1>KPI Monitoring System</h1>
          <p>Sign in as {isAdmin ? 'Admin' : 'Employee'}</p>
        </div>
        <form className="lg-body" onSubmit={submit}>
          <div className="lg-tabs">
            <button type="button" className={isAdmin ? 'on' : ''} onClick={() => switchRole('admin')}>🛡 Admin</button>
            <button type="button" className={!isAdmin ? 'on' : ''} onClick={() => switchRole('employee')}>👤 Employee</button>
          </div>
          {err && <div className="lg-msg err">⚠️ {err}</div>}
          <label>{isAdmin ? 'Username' : 'Your first name'}</label>
          <input value={u} onChange={e => setU(e.target.value)} placeholder={isAdmin ? 'Enter username' : 'Enter first name'} autoComplete="username" autoFocus required />
          <label>Password</label>
          <input type="password" value={p} onChange={e => setP(e.target.value)} placeholder="Enter password" autoComplete="current-password" required />
          <button type="button" className="lg-link" onClick={() => setForgot(true)}>Forgot password?</button>
          <button className="lg-btn" type="submit">{isAdmin ? 'Login as Admin →' : 'Enter Employee Portal →'}</button>
          <small className="lg-hint">{isAdmin ? <>Admin: <code>admin</code> / <code>admin123</code></> : <>Employee: first name / <code>emp123</code></>}</small>
        </form>
      </div>
      {forgot && <ForgotModal onClose={() => setForgot(false)} />}
    </div>);
}
