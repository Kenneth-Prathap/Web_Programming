import { useState } from 'react';
import { useLocal, calcScore, fmtMonth } from '../lib/kpi.js';
import { Card, ScoreBar, ScoreBadge, Empty } from '../components/ui.jsx';
const thisMonth = () => new Date().toISOString().slice(0, 7);
export default function Kpi() {
  const [emps, setEmps] = useLocal('kpi_employees'); const [entries, setEntries] = useLocal('kpi_entries');
  const [f, setF] = useState({ empId: '', month: thisMonth(), tasks: 0, bugs: 0, hours: 0 }); const [q, setQ] = useState('');
  const set = k => e => setF({ ...f, [k]: e.target.value });
  const score = calcScore(+f.tasks, +f.bugs, +f.hours);
  const submit = e => {
    e.preventDefault(); const emp = emps.find(x => x.id == f.empId); if (!emp) return;
    setEmps(emps.map(x => x.id === emp.id ? { ...x, kpi: score } : x));
    setEntries([{ id: Date.now(), empId: emp.id, empName: emp.name, month: f.month, tasks: +f.tasks, bugs: +f.bugs, hours: +f.hours, score }, ...entries]);
    setF({ ...f, tasks: 0, bugs: 0, hours: 0 });
  };
  const del = id => confirm('Delete entry?') && setEntries(entries.filter(e => e.id !== id));
  const shown = entries.filter(e => e.empName.toLowerCase().includes(q.toLowerCase()));
  return (<>
    <h1 className="title">KPI</h1><p className="muted sub">Score = Tasks×5 + Bugs×3 + Hours×0.5</p>
    <div className="grid2">
      <Card title="📝 New entry"><form className="form" onSubmit={submit}>
        <label>Employee<select required value={f.empId} onChange={set('empId')}><option value="">Choose…</option>{emps.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select></label>
        <label>Month<input type="month" required value={f.month} onChange={set('month')} /></label>
        <div className="row3">{[['tasks', '✅ Tasks'], ['bugs', '🐛 Bugs'], ['hours', '⏱ Hours']].map(([k, l]) =>
          <label key={k}>{l}<input type="number" min="0" value={f[k]} onChange={set(k)} /></label>)}</div>
        <div className="preview"><span>Calculated score</span><ScoreBar score={score} /><ScoreBadge score={score} /></div>
        <button className="btn">Save KPI</button></form></Card>
      <Card title="📋 Records" action={<input className="search" placeholder="🔍 Search…" value={q} onChange={e => setQ(e.target.value)} />} pad={false}>
        {!shown.length ? <Empty>No entries.</Empty> :
          <table><thead><tr><th>Employee</th><th>Month</th><th>T/B/H</th><th>Score</th><th /></tr></thead>
            <tbody>{shown.map(e => <tr key={e.id}><td><b>{e.empName}</b></td><td>{fmtMonth(e.month)}</td><td>{e.tasks}/{e.bugs}/{e.hours}</td>
              <td><ScoreBar score={e.score} /></td><td><button className="x" onClick={() => del(e.id)}>✕</button></td></tr>)}</tbody></table>}
      </Card></div></>);
}
