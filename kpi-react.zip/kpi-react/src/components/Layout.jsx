import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
const links = [['/', '🏠', 'Dashboard'], ['/employees', '👥', 'Employees'], ['/kpi', '📝', 'KPI'], ['/attendance', '📅', 'Attendance'], ['/report', '🗓', 'Report']];
export default function Layout() {
  const nav = useNavigate();
  const [dark, setDark] = useState(localStorage.getItem('kpi_theme') === 'dark');
  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; localStorage.setItem('kpi_theme', dark ? 'dark' : 'light'); }, [dark]);
  return (
    <div className="shell">
      <aside className="side">
        <div className="brand"><span className="logo">📊</span><b>KPI Hub</b></div>
        <nav>{links.map(([to, i, l]) => <NavLink key={to} to={to} end={to === '/'} className="nl"><span>{i}</span>{l}</NavLink>)}</nav>
        <div className="side-f">
          <button className="ghost" onClick={() => setDark(!dark)}>{dark ? '☀️ Light' : '🌙 Dark'}</button>
          <button className="ghost danger" onClick={() => { sessionStorage.removeItem('kpi_auth'); nav('/login'); }}>🚪 Logout</button>
        </div>
      </aside>
      <main className="main"><Outlet /></main>
    </div>);
}
