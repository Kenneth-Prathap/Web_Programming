import { perf } from '../lib/kpi.js';
export const Card = ({ title, action, children, pad = true }) => (
  <section className="card">{(title || action) && <header className="card-h"><h3>{title}</h3>{action}</header>}
    <div className={pad ? 'card-b' : ''}>{children}</div></section>);
export const Stat = ({ label, value, color }) => (
  <div className="stat"><span className="stat-l">{label}</span><span className="stat-v" style={{ color }}>{value}</span></div>);
export const ScoreBadge = ({ score }) => { const p = perf(score); return <span className="badge" style={{ '--c': p.color }}>{p.label}</span>; };
export const ScoreBar = ({ score }) => (
  <div className="sbar"><div className="sbar-t"><i style={{ width: Math.min(score / 150 * 100, 100) + '%', background: perf(score).color }} /></div><b>{score}</b></div>);
export const Empty = ({ children }) => <div className="empty">{children}</div>;
