import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Employees from './pages/Employees.jsx';
import Kpi from './pages/Kpi.jsx';
import Attendance from './pages/Attendance.jsx';
import Report from './pages/Report.jsx';
import EmpPortal from './pages/EmpPortal.jsx';
import { getSession } from './lib/auth.js';
// Role-based guard: sends visitors to the login page or to the right area.
const Guard = ({ role, children }) => {
  const s = getSession();
  if (!s) return <Navigate to="/login" replace />;
  if (s.role !== role) return <Navigate to={s.role === 'admin' ? '/' : '/portal'} replace />;
  return children;
};
export default function App() {
  return (<Routes>
    <Route path="/login" element={<Login />} />
    <Route path="/portal" element={<Guard role="employee"><EmpPortal /></Guard>} />
    <Route element={<Guard role="admin"><Layout /></Guard>}>
      <Route index element={<Dashboard />} /><Route path="employees" element={<Employees />} />
      <Route path="kpi" element={<Kpi />} /><Route path="attendance" element={<Attendance />} />
      <Route path="report" element={<Report />} />
    </Route>
  </Routes>);
}
